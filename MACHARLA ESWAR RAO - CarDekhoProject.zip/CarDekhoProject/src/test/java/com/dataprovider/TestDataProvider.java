package com.dataprovider;

import org.testng.annotations.DataProvider;

public class TestDataProvider {

	// TC01 - Valid Car Search
	@DataProvider(name = "validCars")
	public Object[][] validCars() {

		return new Object[][] {
			{"Maruti Suzuki Alto K10"},
			{"Hyundai Creta"},
		};
	}
	// TC02 & TC03 - Suggestions
		@DataProvider(name = "suggestionData")
		public Object[][] suggestionData() {

			return new Object[][] {
				{"Alto","Maruti Suzuki Alto K10"},
				{"Creta","Hyundai Creta"},
				{"Nexon","Tata Nexon"}
			};
		}
	@DataProvider(name = "suggestionDataSelection")
	public Object[][] suggestionData2() {

		return new Object[][] {
			{"Alto"},
			{"Creta"},
			{"Nexon"}
		};
	}
	
	// TC04 & TC05 - Invalid Searches
	@DataProvider(name = "invalidCars")
	public Object[][] invalidCars() {

		return new Object[][] {
			{"@@@@"},          // Special Characters
		};
	}



	// TC06 - Long Search Text
	@DataProvider(name = "longSearchText")
	public Object[][] longSearchText() {

		return new Object[][] {
			{"abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"}
		};
	}


}