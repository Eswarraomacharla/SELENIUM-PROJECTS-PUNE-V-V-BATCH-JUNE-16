package com.dataprovider;

import org.testng.annotations.DataProvider;

import com.utils.ExcelUtils;

public class TestDataProvider2 {

    @DataProvider(name = "filterData")
    public Object[][] filterData()
            throws Exception {

        return ExcelUtils.getExcelData(
                "src/test/resources/ExcelData/Data.xlsx",
                "FilterData");
    }
}