package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@placeholder='Search or Ask a Question']")
	WebElement searchBox;

	// Enter car name and click Enter
	public void enterCarName(String carName) throws Exception{

		searchBox.clear();
		searchBox.sendKeys(carName);
		Thread.sleep(3000);
		searchBox.sendKeys(Keys.ENTER);
	}

	// Enter partial text
	public void searchCar(String carName) throws Exception{

		searchBox.clear();
		searchBox.sendKeys(carName);
		Thread.sleep(3000);
	}

	// Click Enter
	public void pressEnter() {

	
		searchBox.sendKeys(Keys.ENTER);
	}

	// Verify Suggestion
	public boolean isSuggestionDisplayed(WebDriver driver,
			String suggestionText) {

		return driver.findElement(
				By.xpath("//*[contains(text(),'" + suggestionText + "')]"))
				.isDisplayed();
	}

	// Click Suggestion
	public void clickSuggestion(WebDriver driver,
			String suggestionText) {

		driver.findElement(
				By.xpath("//*[contains(text(),'" + suggestionText + "')]"))
		.click();
	}

	// Get H1 Text
	public String getH1Text(WebDriver driver) {

		return driver.findElement(By.xpath("//h1[@class='thcHeading']")).getText();
	}
}
