package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FilterPage extends BasePage {

	public FilterPage(WebDriver driver) {

		super(driver);
	}

	// Budget Filter

	public void selectBudget(String budget) {

		driver.findElement(By.cssSelector("input[name='prices'][title='" + budget + "']")).click();
	}

	// Brand Filter

	public void selectBrand(String brand) {

		driver.findElement(By.cssSelector("input[name='brands'][title='" + brand + "']")).click();
	}

	// Budget checkbox count

	public int getBudgetFilterCount(String budget) {

		String countText = driver.findElement(
				By.xpath(
						"//input[@name='prices' and @title='"
								+ budget
								+ "']/following-sibling::span"))
				.getText();

		countText =countText.replace("(", "").replace(")", "");

		return Integer.parseInt(countText);
	}

	// Budget results count (H2)

	public int getBudgetResultCount() {

		String headingText =
				driver.findElement(By.xpath("//div[contains(@class,'NewCarFilterSearch')]//h2")).getText();

		System.out.println("Budget Heading : "+ headingText);

		return Integer.parseInt(headingText.split(" ")[0]);
	}

	// Brand results count (H1)

	public int getBrandResultCount() {

		String headingText =
				driver.findElement(
						By.xpath(
								"//div[contains(@class,'NewCarFilterSearch')]//h1"))
				.getText();

		System.out.println(
				"Brand Heading : "
						+ headingText);

		return Integer.parseInt(
				headingText.replaceAll("[^0-9]", " ")
				.trim()
				.split("\\s+")[0]);
	}

	public List<WebElement> getCarNames() {

		return driver.findElements(By.xpath("//h3"));
	}

	public void clearAllFilters() {

		driver.navigate().refresh();
	}
}