package com.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtil {

	public static String captureScreenshot(
	        WebDriver driver,
	        String fileName) {

	    String folderPath =
	            System.getProperty("user.dir")
	            + "/target/ExtentReports/Screenshots/";

	    File folder =
	            new File(folderPath);

	    if(!folder.exists()) {

	        folder.mkdirs();
	    }

	    String path =
	            folderPath
	            + fileName
	            + ".png";

	    File src =
	            ((TakesScreenshot) driver)
	            .getScreenshotAs(OutputType.FILE);

	    try {

	        FileUtils.copyFile(
	                src,
	                new File(path));

	    } catch(IOException e) {

	        e.printStackTrace();
	    }

	    return path;
	}
}