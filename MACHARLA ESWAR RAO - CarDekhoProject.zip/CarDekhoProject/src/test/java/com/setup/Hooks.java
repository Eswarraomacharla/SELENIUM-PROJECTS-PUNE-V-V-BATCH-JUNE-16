package com.setup;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utils.ExtentManager;
import com.utils.ScreenshotUtil;

public class Hooks extends SetupDriver {

    public static ExtentReports extent;
    public static ExtentTest test;

    @BeforeMethod
    public void setUp(Method method)
            throws Exception {

        launchBrowser("chrome");

        extent = ExtentManager.getReport();

        test = extent.createTest(
                method.getName());
    }

    @AfterMethod
    public void tearDown(ITestResult result) {

        if (result.getStatus()
                == ITestResult.FAILURE) {

            String fileName =
                    result.getMethod()
                          .getMethodName();

            Object[] parameters =
                    result.getParameters();

            if (parameters.length > 0) {

                fileName =
                        fileName + "_"
                        + parameters[0].toString();
            }

            fileName =
                    fileName + "_"
                    + System.currentTimeMillis();

            String screenshotPath =
                    ScreenshotUtil.captureScreenshot(
                            driver,
                            fileName);

            test.fail(
                    result.getThrowable());

            try {

                test.addScreenCaptureFromPath(
                        screenshotPath);

            } catch (Exception e) {

                e.printStackTrace();
            }

        } else if (result.getStatus()
                == ITestResult.SUCCESS) {

            test.pass("Test Passed");

        } else {

            test.skip("Test Skipped");
        }

        extent.flush();

        closeBrowser();
    }
}