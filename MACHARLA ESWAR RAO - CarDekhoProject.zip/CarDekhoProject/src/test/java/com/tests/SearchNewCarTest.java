package com.tests;
import org.openqa.selenium.By;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.dataprovider.TestDataProvider;
import com.pages.HomePage;
import com.setup.Hooks;

public class SearchNewCarTest extends Hooks {

	// TC01 - Verify search with valid car names
	@Test(dataProvider = "validCars",
			dataProviderClass = TestDataProvider.class,
			priority = 1)
	public void verifyValidCarSearch(String carName)
			throws Exception {


		HomePage home = new HomePage(driver);


		home.enterCarName(carName);


		Thread.sleep(5000);


		String actualH1 =
				driver.findElement(By.xpath("//h1"))
				.getText();


		System.out.println("Expected : " + carName);
		System.out.println("Actual   : " + actualH1);


		Assert.assertTrue(
				actualH1.toLowerCase()
				.contains(carName.toLowerCase()),
				"Expected car page not displayed");
	}


	// TC02 - Verify search suggestions appear
	@Test(dataProvider = "suggestionData",
			dataProviderClass = TestDataProvider.class,
			priority = 2)
	public void verifySearchSuggestions(String searchText,
			String expectedSuggestion)
					throws Exception {

		HomePage home = new HomePage(driver);

		home.searchCar(searchText);

		Thread.sleep(3000);

		boolean suggestionDisplayed =
				driver.findElement(
						By.xpath("//*[contains(text(),'" +
								expectedSuggestion + "')]"))
				.isDisplayed();

		Assert.assertTrue(
				suggestionDisplayed,
				"Suggestion not displayed");
	}

	@Test(dataProvider = "suggestionDataSelection",
			dataProviderClass = TestDataProvider.class,
			priority = 3)
	public void  verifySuggestionSelection(String carName)
			throws Exception {


		HomePage home = new HomePage(driver);


		home.enterCarName(carName);


		Thread.sleep(5000);


		String actualH1 =
				driver.findElement(By.xpath("//h1"))
				.getText();


		System.out.println("Expected : " + carName);
		System.out.println("Actual   : " + actualH1);


		Assert.assertTrue(
				actualH1.toLowerCase()
				.contains(carName.toLowerCase()),
				"Expected car page not displayed");
	}

	// TC04 & TC05 - Special Characters and Non Existing Car
	@Test(dataProvider = "invalidCars",
			dataProviderClass = TestDataProvider.class,
			priority = 4)
	public void verifyInvalidSearch(String searchText)
			throws Exception {

		HomePage home = new HomePage(driver);

		home.enterCarName(searchText);

		Thread.sleep(5000);

		String pageSource =
				driver.getPageSource();

		Assert.assertTrue(
				pageSource.contains("No")
				|| pageSource.contains("not found")
				|| pageSource.contains("Sorry")
				|| pageSource.contains("result"),
				"Expected error message not displayed");

		System.out.println(
				"Handled Invalid Search : "
						+ searchText);
	}

	// TC06 - Long Search Text
	@Test(dataProvider = "longSearchText",
			dataProviderClass = TestDataProvider.class,
			priority = 5)
	public void verifyLongSearchText(String longText)
			throws Exception {

		HomePage home = new HomePage(driver);

		home.enterCarName(longText);

		Thread.sleep(5000);

		Assert.assertNotNull(driver.getTitle());

		Assert.assertTrue(
				driver.getTitle().length() > 0,
				"Application crashed after long search text");

		System.out.println(
				"Long Search Text Handled Successfully");
	}
}