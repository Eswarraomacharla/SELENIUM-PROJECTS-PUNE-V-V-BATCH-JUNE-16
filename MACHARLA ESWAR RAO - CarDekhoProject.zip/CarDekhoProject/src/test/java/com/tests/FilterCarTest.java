package com.tests;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.dataprovider.FilterDataProvider;
import com.pages.FilterPage;
import com.setup.Hooks;

public class FilterCarTest extends Hooks {

	// TC_CD_NC_013 - Budget Filter

	@Test(dataProvider = "budgetData",
			dataProviderClass = FilterDataProvider.class,
			priority = 1)
	public void verifyBudgetFilter(String budget)
			throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		int expectedCount =
				page.getBudgetFilterCount(budget);

		page.selectBudget(budget);

		Thread.sleep(5000);

		int actualCount =
				page.getBudgetResultCount();

		System.out.println(
				"Expected Count : "
						+ expectedCount);

		System.out.println(
				"Actual Count : "
						+ actualCount);

		Assert.assertEquals(
				actualCount,
				expectedCount,
				"Budget Filter Count Mismatch");
	}

	// TC_CD_NC_014 - Brand Filter

	@Test(dataProvider = "brandData",
			dataProviderClass = FilterDataProvider.class,
			priority = 2)
	public void verifyBrandFilter(String brand)
			throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		page.selectBrand(brand);

		Thread.sleep(5000);

		int count =
				page.getBrandResultCount();

		System.out.println(
				"Brand : " + brand +
				" | Count : " + count);

		Assert.assertTrue(
				count > 0,
				"No cars displayed");
	}

	// TC_CD_NC_015 - Multiple Filters

	@Test(dataProvider = "multipleFilterData",
			dataProviderClass = FilterDataProvider.class,
			priority = 3)
	public void verifyMultipleFilters(
			String budget,
			String brand)
					throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		page.selectBudget(budget);

		Thread.sleep(2000);

		page.selectBrand(brand);

		Thread.sleep(5000);

		int count =
				page.getBrandResultCount();

		System.out.println(
				"Budget : " + budget +
				" | Brand : " + brand +
				" | Count : " + count);

		Assert.assertTrue(
				count > 0,
				"No cars displayed");
	}

	// TC_CD_NC_016 - Irrelevant Cars

	@Test(dataProvider = "irrelevantBrandData",
			dataProviderClass = FilterDataProvider.class,
			priority = 4)
	public void verifyIrrelevantCars(
			String selectedBrand,
			String unwantedBrand)
					throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		page.selectBrand(selectedBrand);

		Thread.sleep(5000);

		List<WebElement> cars =
				page.getCarNames();

		for (WebElement car : cars) {

			String carName =
					car.getText();

			System.out.println(carName);

			Assert.assertFalse(
					carName.toLowerCase()
					.contains(
							unwantedBrand.toLowerCase()),
					unwantedBrand
					+ " displayed after selecting "
					+ selectedBrand);
		}
	}

	// TC_CD_NC_017 - Clear Filters

	@Test(dataProvider = "clearFilterData",
			dataProviderClass = FilterDataProvider.class,
			priority = 5)
	public void verifyClearFilters(String brand)
			throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		page.selectBrand(brand);

		Thread.sleep(3000);

		page.clearAllFilters();

		Thread.sleep(3000);

		Assert.assertTrue(true);

		System.out.println(
				"Filters Cleared Successfully");
	}

	// TC_CD_NC_018 - Result Count

	@Test(dataProvider = "resultCountData",
			dataProviderClass = FilterDataProvider.class,
			priority = 6)
	public void verifyResultCount(String brand)
			throws Exception {

		driver.get("https://www.cardekho.com/filter/new-cars");

		FilterPage page =
				new FilterPage(driver);

		page.selectBrand(brand);

		Thread.sleep(5000);

		int count =
				page.getBrandResultCount();

		System.out.println(
				"Brand : " + brand +
				" | Result Count : " + count);

		Assert.assertTrue(
				count > 0,
				"Result count is zero");
	}
}